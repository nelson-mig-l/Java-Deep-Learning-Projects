package com.packt.JavaDL.PricePrediction.Representation;

/**
 * Created by zhanghao on 28/9/17.
 * @author ZHANG HAO
 */
public enum PriceCategory {
    OPEN, CLOSE, LOW, HIGH, VOLUME, ALL
}
